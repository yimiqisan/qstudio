.. automodule:: scipy.optimize.nonlin
