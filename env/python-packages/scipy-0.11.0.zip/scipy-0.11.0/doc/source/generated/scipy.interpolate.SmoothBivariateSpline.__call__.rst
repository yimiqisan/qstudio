scipy.interpolate.SmoothBivariateSpline.__call__
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.__call__