scipy.constants.lambda2nu
=========================

.. currentmodule:: scipy.constants

.. autofunction:: lambda2nu