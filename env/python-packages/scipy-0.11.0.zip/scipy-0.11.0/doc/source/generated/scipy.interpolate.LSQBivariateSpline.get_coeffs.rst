scipy.interpolate.LSQBivariateSpline.get_coeffs
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.get_coeffs