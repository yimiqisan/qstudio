scipy.optimize.broyden1
=======================

.. currentmodule:: scipy.optimize

.. autofunction:: broyden1