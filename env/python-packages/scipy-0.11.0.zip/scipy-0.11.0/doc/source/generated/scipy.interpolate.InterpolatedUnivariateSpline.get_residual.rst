scipy.interpolate.InterpolatedUnivariateSpline.get_residual
===========================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.get_residual