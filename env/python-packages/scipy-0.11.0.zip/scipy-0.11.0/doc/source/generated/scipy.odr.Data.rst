scipy.odr.Data
==============

.. currentmodule:: scipy.odr

.. autoclass:: Data

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         Data.set_meta



   

