scipy.linalg.tanm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: tanm