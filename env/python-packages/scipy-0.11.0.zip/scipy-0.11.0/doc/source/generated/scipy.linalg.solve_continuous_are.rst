scipy.linalg.solve_continuous_are
=================================

.. currentmodule:: scipy.linalg

.. autofunction:: solve_continuous_are