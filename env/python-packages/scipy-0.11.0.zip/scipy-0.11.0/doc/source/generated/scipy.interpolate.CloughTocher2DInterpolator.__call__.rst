scipy.interpolate.CloughTocher2DInterpolator.__call__
=====================================================

.. currentmodule:: scipy.interpolate

.. automethod:: CloughTocher2DInterpolator.__call__