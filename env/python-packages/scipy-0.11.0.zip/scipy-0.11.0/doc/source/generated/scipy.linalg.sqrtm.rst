scipy.linalg.sqrtm
==================

.. currentmodule:: scipy.linalg

.. autofunction:: sqrtm