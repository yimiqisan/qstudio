scipy.ndimage.filters.laplace
=============================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: laplace