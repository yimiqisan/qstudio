scipy.misc.imrotate
===================

.. currentmodule:: scipy.misc

.. autofunction:: imrotate