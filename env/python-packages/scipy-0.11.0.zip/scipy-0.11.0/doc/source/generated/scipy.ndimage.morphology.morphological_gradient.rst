scipy.ndimage.morphology.morphological_gradient
===============================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: morphological_gradient