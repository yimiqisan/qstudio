scipy.optimize.brent
====================

.. currentmodule:: scipy.optimize

.. autofunction:: brent