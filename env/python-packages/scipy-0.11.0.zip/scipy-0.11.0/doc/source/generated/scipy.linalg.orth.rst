scipy.linalg.orth
=================

.. currentmodule:: scipy.linalg

.. autofunction:: orth