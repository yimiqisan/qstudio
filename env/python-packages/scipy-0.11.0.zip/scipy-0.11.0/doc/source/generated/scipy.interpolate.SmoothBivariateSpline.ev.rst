scipy.interpolate.SmoothBivariateSpline.ev
==========================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.ev