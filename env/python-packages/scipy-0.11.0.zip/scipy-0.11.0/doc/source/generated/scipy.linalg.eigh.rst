scipy.linalg.eigh
=================

.. currentmodule:: scipy.linalg

.. autofunction:: eigh