scipy.cluster.vq.whiten
=======================

.. currentmodule:: scipy.cluster.vq

.. autofunction:: whiten