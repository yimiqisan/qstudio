scipy.optimize.brute
====================

.. currentmodule:: scipy.optimize

.. autofunction:: brute