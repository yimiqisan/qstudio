scipy.ndimage.interpolation.spline_filter
=========================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: spline_filter