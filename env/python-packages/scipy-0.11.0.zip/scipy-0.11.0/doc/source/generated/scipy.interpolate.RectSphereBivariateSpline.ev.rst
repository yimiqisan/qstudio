scipy.interpolate.RectSphereBivariateSpline.ev
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectSphereBivariateSpline.ev