scipy.linalg.solve_sylvester
============================

.. currentmodule:: scipy.linalg

.. autofunction:: solve_sylvester