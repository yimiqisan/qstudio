scipy.interpolate.RectSphereBivariateSpline.__call__
====================================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectSphereBivariateSpline.__call__