scipy.linalg.cosm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: cosm