scipy.ndimage.filters.sobel
===========================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: sobel