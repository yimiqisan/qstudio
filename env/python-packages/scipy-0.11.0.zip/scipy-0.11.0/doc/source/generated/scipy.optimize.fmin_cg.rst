scipy.optimize.fmin_cg
======================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_cg