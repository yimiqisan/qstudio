scipy.odr.RealData.set_meta
===========================

.. currentmodule:: scipy.odr

.. automethod:: RealData.set_meta