scipy.io.netcdf.netcdf_variable.typecode
========================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_variable.typecode