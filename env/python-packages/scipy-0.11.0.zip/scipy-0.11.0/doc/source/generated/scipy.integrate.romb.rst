scipy.integrate.romb
====================

.. currentmodule:: scipy.integrate

.. autofunction:: romb