scipy.interpolate.interp1d.__call__
===================================

.. currentmodule:: scipy.interpolate

.. automethod:: interp1d.__call__