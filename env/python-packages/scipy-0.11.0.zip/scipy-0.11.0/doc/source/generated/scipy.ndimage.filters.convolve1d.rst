scipy.ndimage.filters.convolve1d
================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: convolve1d