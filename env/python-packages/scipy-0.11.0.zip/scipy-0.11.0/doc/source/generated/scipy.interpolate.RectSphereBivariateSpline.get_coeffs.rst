scipy.interpolate.RectSphereBivariateSpline.get_coeffs
======================================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectSphereBivariateSpline.get_coeffs