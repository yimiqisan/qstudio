scipy.cluster.hierarchy.num_obs_linkage
=======================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: num_obs_linkage