scipy.integrate.romberg
=======================

.. currentmodule:: scipy.integrate

.. autofunction:: romberg