scipy.cluster.hierarchy.median
==============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: median