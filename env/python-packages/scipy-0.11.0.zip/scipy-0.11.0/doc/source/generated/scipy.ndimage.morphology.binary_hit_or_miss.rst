scipy.ndimage.morphology.binary_hit_or_miss
===========================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_hit_or_miss