scipy.constants.find
====================

.. currentmodule:: scipy.constants

.. autofunction:: find