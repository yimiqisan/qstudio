scipy.interpolate.BivariateSpline.integral
==========================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.integral