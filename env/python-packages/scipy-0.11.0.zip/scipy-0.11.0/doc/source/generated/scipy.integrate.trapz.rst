scipy.integrate.trapz
=====================

.. currentmodule:: scipy.integrate

.. autofunction:: trapz