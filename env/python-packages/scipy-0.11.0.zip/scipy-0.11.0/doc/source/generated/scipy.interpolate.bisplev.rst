scipy.interpolate.bisplev
=========================

.. currentmodule:: scipy.interpolate

.. autofunction:: bisplev