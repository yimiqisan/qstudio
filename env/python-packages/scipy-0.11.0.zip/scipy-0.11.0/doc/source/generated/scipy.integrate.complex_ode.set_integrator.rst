scipy.integrate.complex_ode.set_integrator
==========================================

.. currentmodule:: scipy.integrate

.. automethod:: complex_ode.set_integrator