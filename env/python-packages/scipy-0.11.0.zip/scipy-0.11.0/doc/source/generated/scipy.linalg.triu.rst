scipy.linalg.triu
=================

.. currentmodule:: scipy.linalg

.. autofunction:: triu