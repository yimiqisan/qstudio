scipy.interpolate.KroghInterpolator
===================================

.. currentmodule:: scipy.interpolate

.. autoclass:: KroghInterpolator

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         KroghInterpolator.__call__
         KroghInterpolator.derivative
         KroghInterpolator.derivatives



   

