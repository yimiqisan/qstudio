scipy.misc.imshow
=================

.. currentmodule:: scipy.misc

.. autofunction:: imshow