scipy.optimize.fmin_tnc
=======================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_tnc