scipy.optimize.fmin_ncg
=======================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_ncg