scipy.ndimage.measurements.standard_deviation
=============================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: standard_deviation