scipy.ndimage.morphology.distance_transform_edt
===============================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: distance_transform_edt