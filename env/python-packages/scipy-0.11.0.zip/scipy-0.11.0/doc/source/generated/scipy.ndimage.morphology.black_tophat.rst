scipy.ndimage.morphology.black_tophat
=====================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: black_tophat