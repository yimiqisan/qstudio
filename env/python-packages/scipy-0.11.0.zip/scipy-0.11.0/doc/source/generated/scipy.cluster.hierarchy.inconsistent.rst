scipy.cluster.hierarchy.inconsistent
====================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: inconsistent