scipy.fftpack._fftpack.destroy_zfftnd_cache
===========================================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: destroy_zfftnd_cache