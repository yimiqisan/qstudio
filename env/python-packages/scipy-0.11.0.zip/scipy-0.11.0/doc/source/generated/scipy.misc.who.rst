scipy.misc.who
==============

.. currentmodule:: scipy.misc

.. autofunction:: who