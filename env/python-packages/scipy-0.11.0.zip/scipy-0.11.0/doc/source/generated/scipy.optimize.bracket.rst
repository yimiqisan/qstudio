scipy.optimize.bracket
======================

.. currentmodule:: scipy.optimize

.. autofunction:: bracket