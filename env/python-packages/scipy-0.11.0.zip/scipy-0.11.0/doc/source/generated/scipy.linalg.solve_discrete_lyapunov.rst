scipy.linalg.solve_discrete_lyapunov
====================================

.. currentmodule:: scipy.linalg

.. autofunction:: solve_discrete_lyapunov