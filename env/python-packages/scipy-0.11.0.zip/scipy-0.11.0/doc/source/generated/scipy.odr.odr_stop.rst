scipy.odr.odr_stop
==================

.. currentmodule:: scipy.odr

.. autoexception:: odr_stop