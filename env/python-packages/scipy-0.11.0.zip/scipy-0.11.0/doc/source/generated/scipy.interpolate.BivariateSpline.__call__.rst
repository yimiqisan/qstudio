scipy.interpolate.BivariateSpline.__call__
==========================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.__call__