scipy.cluster.hierarchy.to_mlab_linkage
=======================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: to_mlab_linkage