scipy.interpolate.spalde
========================

.. currentmodule:: scipy.interpolate

.. autofunction:: spalde