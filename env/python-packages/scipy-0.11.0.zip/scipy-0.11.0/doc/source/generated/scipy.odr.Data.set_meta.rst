scipy.odr.Data.set_meta
=======================

.. currentmodule:: scipy.odr

.. automethod:: Data.set_meta