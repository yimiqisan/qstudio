scipy.odr.ODR
=============

.. currentmodule:: scipy.odr

.. autoclass:: ODR

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         ODR.restart
         ODR.run
         ODR.set_iprint
         ODR.set_job



   

