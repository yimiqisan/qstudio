scipy.interpolate.LSQUnivariateSpline
=====================================

.. currentmodule:: scipy.interpolate

.. autoclass:: LSQUnivariateSpline

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         LSQUnivariateSpline.__call__
         LSQUnivariateSpline.derivatives
         LSQUnivariateSpline.get_coeffs
         LSQUnivariateSpline.get_knots
         LSQUnivariateSpline.get_residual
         LSQUnivariateSpline.integral
         LSQUnivariateSpline.roots
         LSQUnivariateSpline.set_smoothing_factor



   

