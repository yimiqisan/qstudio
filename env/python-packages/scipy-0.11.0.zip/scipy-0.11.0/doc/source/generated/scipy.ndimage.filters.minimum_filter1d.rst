scipy.ndimage.filters.minimum_filter1d
======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: minimum_filter1d