scipy.integrate.ode.successful
==============================

.. currentmodule:: scipy.integrate

.. automethod:: ode.successful