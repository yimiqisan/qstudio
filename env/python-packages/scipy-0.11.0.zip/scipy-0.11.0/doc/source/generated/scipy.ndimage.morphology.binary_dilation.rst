scipy.ndimage.morphology.binary_dilation
========================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_dilation