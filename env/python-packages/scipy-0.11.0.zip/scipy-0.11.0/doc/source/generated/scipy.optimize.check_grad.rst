scipy.optimize.check_grad
=========================

.. currentmodule:: scipy.optimize

.. autofunction:: check_grad