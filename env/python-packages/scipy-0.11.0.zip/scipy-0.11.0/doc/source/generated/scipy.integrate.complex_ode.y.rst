scipy.integrate.complex_ode.y
=============================

.. currentmodule:: scipy.integrate

.. autoattribute:: complex_ode.y