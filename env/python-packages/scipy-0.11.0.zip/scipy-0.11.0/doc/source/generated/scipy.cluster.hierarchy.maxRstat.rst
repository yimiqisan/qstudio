scipy.cluster.hierarchy.maxRstat
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: maxRstat