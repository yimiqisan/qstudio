scipy.ndimage.morphology.iterate_structure
==========================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: iterate_structure