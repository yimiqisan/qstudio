scipy.ndimage.morphology.distance_transform_cdt
===============================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: distance_transform_cdt