scipy.io.netcdf.netcdf_variable.itemsize
========================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_variable.itemsize