scipy.cluster.hierarchy.ClusterNode.get_left
============================================

.. currentmodule:: scipy.cluster.hierarchy

.. automethod:: ClusterNode.get_left