scipy.misc.derivative
=====================

.. currentmodule:: scipy.misc

.. autofunction:: derivative