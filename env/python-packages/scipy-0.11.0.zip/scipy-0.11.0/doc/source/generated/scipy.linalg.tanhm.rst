scipy.linalg.tanhm
==================

.. currentmodule:: scipy.linalg

.. autofunction:: tanhm