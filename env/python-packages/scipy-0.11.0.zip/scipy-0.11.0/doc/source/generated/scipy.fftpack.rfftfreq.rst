scipy.fftpack.rfftfreq
======================

.. currentmodule:: scipy.fftpack

.. autofunction:: rfftfreq