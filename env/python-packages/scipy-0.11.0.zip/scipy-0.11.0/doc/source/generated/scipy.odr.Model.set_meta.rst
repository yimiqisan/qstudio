scipy.odr.Model.set_meta
========================

.. currentmodule:: scipy.odr

.. automethod:: Model.set_meta