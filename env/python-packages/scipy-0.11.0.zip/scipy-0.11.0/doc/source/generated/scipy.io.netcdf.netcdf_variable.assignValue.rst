scipy.io.netcdf.netcdf_variable.assignValue
===========================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_variable.assignValue