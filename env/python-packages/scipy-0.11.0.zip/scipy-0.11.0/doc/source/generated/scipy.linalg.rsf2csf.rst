scipy.linalg.rsf2csf
====================

.. currentmodule:: scipy.linalg

.. autofunction:: rsf2csf