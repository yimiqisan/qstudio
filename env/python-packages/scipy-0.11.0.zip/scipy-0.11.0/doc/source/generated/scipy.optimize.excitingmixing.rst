scipy.optimize.excitingmixing
=============================

.. currentmodule:: scipy.optimize

.. autofunction:: excitingmixing