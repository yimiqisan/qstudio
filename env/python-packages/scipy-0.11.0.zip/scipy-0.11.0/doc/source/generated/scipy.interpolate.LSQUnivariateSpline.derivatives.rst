scipy.interpolate.LSQUnivariateSpline.derivatives
=================================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.derivatives