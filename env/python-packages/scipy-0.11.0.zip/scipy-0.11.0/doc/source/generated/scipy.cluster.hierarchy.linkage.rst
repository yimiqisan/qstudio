scipy.cluster.hierarchy.linkage
===============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: linkage