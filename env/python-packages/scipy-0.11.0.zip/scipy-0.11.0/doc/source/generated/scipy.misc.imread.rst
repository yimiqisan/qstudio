scipy.misc.imread
=================

.. currentmodule:: scipy.misc

.. autofunction:: imread