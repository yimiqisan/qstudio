scipy.ndimage.morphology.generate_binary_structure
==================================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: generate_binary_structure