scipy.ndimage.morphology.morphological_laplace
==============================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: morphological_laplace