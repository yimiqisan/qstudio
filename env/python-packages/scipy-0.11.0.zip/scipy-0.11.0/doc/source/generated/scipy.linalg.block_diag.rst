scipy.linalg.block_diag
=======================

.. currentmodule:: scipy.linalg

.. autofunction:: block_diag