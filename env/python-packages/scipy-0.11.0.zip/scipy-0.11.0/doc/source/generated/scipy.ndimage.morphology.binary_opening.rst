scipy.ndimage.morphology.binary_opening
=======================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_opening