scipy.interpolate.InterpolatedUnivariateSpline.__call__
=======================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.__call__