scipy.ndimage.morphology.white_tophat
=====================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: white_tophat