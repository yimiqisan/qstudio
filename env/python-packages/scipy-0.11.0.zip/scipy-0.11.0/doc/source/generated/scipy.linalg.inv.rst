scipy.linalg.inv
================

.. currentmodule:: scipy.linalg

.. autofunction:: inv