scipy.ndimage.filters.gaussian_filter
=====================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: gaussian_filter