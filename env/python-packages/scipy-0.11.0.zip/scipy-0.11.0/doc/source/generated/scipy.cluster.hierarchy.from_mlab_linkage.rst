scipy.cluster.hierarchy.from_mlab_linkage
=========================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: from_mlab_linkage