scipy.interpolate.RectSphereBivariateSpline
===========================================

.. currentmodule:: scipy.interpolate

.. autoclass:: RectSphereBivariateSpline

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         RectSphereBivariateSpline.__call__
         RectSphereBivariateSpline.ev
         RectSphereBivariateSpline.get_coeffs
         RectSphereBivariateSpline.get_knots
         RectSphereBivariateSpline.get_residual



   

