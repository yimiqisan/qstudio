scipy.fftpack.fftn
==================

.. currentmodule:: scipy.fftpack

.. autofunction:: fftn