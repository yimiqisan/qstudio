scipy.ndimage.measurements.maximum
==================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: maximum