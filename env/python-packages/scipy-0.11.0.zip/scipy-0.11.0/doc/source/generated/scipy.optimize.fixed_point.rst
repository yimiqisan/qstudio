scipy.optimize.fixed_point
==========================

.. currentmodule:: scipy.optimize

.. autofunction:: fixed_point