scipy.constants.C2F
===================

.. currentmodule:: scipy.constants

.. autofunction:: C2F