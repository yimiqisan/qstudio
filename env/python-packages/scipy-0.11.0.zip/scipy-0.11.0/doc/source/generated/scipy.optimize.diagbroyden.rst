scipy.optimize.diagbroyden
==========================

.. currentmodule:: scipy.optimize

.. autofunction:: diagbroyden