scipy.ndimage.measurements.maximum_position
===========================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: maximum_position