scipy.interpolate.LSQUnivariateSpline.get_residual
==================================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.get_residual