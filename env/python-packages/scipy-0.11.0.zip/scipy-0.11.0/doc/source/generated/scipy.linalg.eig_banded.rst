scipy.linalg.eig_banded
=======================

.. currentmodule:: scipy.linalg

.. autofunction:: eig_banded