scipy.ndimage.morphology.binary_erosion
=======================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_erosion