scipy.optimize.anderson
=======================

.. currentmodule:: scipy.optimize

.. autofunction:: anderson