scipy.linalg.qz
===============

.. currentmodule:: scipy.linalg

.. autofunction:: qz