scipy.ndimage.measurements.variance
===================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: variance