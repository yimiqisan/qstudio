scipy.odr.ODR.set_iprint
========================

.. currentmodule:: scipy.odr

.. automethod:: ODR.set_iprint