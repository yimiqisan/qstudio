scipy.ndimage.measurements.mean
===============================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: mean