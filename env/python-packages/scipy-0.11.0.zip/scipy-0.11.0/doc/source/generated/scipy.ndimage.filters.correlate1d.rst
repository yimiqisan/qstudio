scipy.ndimage.filters.correlate1d
=================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: correlate1d