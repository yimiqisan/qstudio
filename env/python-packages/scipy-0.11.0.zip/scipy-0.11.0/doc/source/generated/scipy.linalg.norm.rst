scipy.linalg.norm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: norm