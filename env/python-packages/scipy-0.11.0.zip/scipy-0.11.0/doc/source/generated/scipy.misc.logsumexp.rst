scipy.misc.logsumexp
====================

.. currentmodule:: scipy.misc

.. autofunction:: logsumexp