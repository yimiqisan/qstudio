scipy.ndimage.measurements.watershed_ift
========================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: watershed_ift