scipy.misc.fromimage
====================

.. currentmodule:: scipy.misc

.. autofunction:: fromimage