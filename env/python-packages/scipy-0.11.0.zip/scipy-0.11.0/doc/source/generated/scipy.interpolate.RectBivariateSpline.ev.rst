scipy.interpolate.RectBivariateSpline.ev
========================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectBivariateSpline.ev