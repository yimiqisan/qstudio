scipy.ndimage.morphology.grey_closing
=====================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: grey_closing