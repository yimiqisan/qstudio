scipy.ndimage.morphology.grey_erosion
=====================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: grey_erosion