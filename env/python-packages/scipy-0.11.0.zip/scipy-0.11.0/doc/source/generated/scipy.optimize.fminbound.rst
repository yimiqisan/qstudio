scipy.optimize.fminbound
========================

.. currentmodule:: scipy.optimize

.. autofunction:: fminbound