scipy.integrate.simps
=====================

.. currentmodule:: scipy.integrate

.. autofunction:: simps