scipy.optimize.fmin_slsqp
=========================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_slsqp