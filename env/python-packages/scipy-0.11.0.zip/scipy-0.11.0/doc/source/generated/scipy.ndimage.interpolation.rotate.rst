scipy.ndimage.interpolation.rotate
==================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: rotate