scipy.integrate.ode.integrate
=============================

.. currentmodule:: scipy.integrate

.. automethod:: ode.integrate