scipy.interpolate.bisplrep
==========================

.. currentmodule:: scipy.interpolate

.. autofunction:: bisplrep