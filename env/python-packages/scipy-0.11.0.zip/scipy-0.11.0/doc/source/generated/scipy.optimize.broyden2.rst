scipy.optimize.broyden2
=======================

.. currentmodule:: scipy.optimize

.. autofunction:: broyden2