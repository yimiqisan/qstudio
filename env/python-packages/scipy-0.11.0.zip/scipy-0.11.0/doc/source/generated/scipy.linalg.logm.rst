scipy.linalg.logm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: logm