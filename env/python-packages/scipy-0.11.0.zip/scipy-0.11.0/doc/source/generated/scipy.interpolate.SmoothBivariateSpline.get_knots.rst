scipy.interpolate.SmoothBivariateSpline.get_knots
=================================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.get_knots