scipy.optimize.anneal
=====================

.. currentmodule:: scipy.optimize

.. autofunction:: anneal