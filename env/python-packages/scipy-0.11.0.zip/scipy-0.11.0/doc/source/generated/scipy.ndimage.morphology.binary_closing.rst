scipy.ndimage.morphology.binary_closing
=======================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_closing