scipy.optimize.fmin_l_bfgs_b
============================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_l_bfgs_b