scipy.linalg.pinv2
==================

.. currentmodule:: scipy.linalg

.. autofunction:: pinv2