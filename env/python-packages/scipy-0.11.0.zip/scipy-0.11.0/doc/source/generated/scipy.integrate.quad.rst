scipy.integrate.quad
====================

.. currentmodule:: scipy.integrate

.. autofunction:: quad