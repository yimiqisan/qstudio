scipy.linalg.hilbert
====================

.. currentmodule:: scipy.linalg

.. autofunction:: hilbert