scipy.odr.ODR.restart
=====================

.. currentmodule:: scipy.odr

.. automethod:: ODR.restart