scipy.interpolate.BivariateSpline.get_knots
===========================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.get_knots