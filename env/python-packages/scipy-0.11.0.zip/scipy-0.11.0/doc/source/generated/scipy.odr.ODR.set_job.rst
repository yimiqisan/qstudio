scipy.odr.ODR.set_job
=====================

.. currentmodule:: scipy.odr

.. automethod:: ODR.set_job