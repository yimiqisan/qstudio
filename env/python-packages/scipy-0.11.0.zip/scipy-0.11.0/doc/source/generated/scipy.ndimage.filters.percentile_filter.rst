scipy.ndimage.filters.percentile_filter
=======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: percentile_filter