scipy.interpolate.sproot
========================

.. currentmodule:: scipy.interpolate

.. autofunction:: sproot