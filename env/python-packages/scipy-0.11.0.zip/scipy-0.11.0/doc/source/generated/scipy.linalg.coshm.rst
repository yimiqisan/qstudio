scipy.linalg.coshm
==================

.. currentmodule:: scipy.linalg

.. autofunction:: coshm