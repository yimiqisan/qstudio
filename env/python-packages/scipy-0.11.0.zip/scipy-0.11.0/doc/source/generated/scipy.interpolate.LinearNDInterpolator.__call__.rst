scipy.interpolate.LinearNDInterpolator.__call__
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LinearNDInterpolator.__call__