scipy.io.netcdf.netcdf_file.createVariable
==========================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_file.createVariable