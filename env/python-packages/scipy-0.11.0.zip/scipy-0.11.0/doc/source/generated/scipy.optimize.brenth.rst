scipy.optimize.brenth
=====================

.. currentmodule:: scipy.optimize

.. autofunction:: brenth