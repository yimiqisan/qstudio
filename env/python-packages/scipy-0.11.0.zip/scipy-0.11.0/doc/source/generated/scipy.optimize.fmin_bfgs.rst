scipy.optimize.fmin_bfgs
========================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_bfgs