scipy.ndimage.measurements.histogram
====================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: histogram