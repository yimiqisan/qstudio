scipy.optimize.fmin_cobyla
==========================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_cobyla