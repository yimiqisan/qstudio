scipy.linalg.det
================

.. currentmodule:: scipy.linalg

.. autofunction:: det