scipy.linalg.solve_lyapunov
===========================

.. currentmodule:: scipy.linalg

.. autofunction:: solve_lyapunov