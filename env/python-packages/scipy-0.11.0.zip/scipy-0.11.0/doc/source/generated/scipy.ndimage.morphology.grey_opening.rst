scipy.ndimage.morphology.grey_opening
=====================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: grey_opening