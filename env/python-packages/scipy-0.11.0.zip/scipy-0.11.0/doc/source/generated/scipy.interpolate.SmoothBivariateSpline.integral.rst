scipy.interpolate.SmoothBivariateSpline.integral
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.integral