scipy.ndimage.morphology.grey_dilation
======================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: grey_dilation