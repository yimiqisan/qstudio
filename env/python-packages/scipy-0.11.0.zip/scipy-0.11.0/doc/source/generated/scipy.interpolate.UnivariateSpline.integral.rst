scipy.interpolate.UnivariateSpline.integral
===========================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.integral