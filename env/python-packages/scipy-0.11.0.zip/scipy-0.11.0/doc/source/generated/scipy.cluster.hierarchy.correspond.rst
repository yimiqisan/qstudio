scipy.cluster.hierarchy.correspond
==================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: correspond