scipy.ndimage.morphology.binary_fill_holes
==========================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_fill_holes