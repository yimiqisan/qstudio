scipy.ndimage.measurements.sum
==============================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: sum