scipy.interpolate.LSQBivariateSpline.get_residual
=================================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.get_residual