scipy.optimize.fsolve
=====================

.. currentmodule:: scipy.optimize

.. autofunction:: fsolve