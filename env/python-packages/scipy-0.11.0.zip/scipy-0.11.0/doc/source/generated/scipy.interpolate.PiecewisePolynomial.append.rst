scipy.interpolate.PiecewisePolynomial.append
============================================

.. currentmodule:: scipy.interpolate

.. automethod:: PiecewisePolynomial.append