scipy.interpolate.piecewise_polynomial_interpolate
==================================================

.. currentmodule:: scipy.interpolate

.. autofunction:: piecewise_polynomial_interpolate