scipy.interpolate.pchip
=======================

.. currentmodule:: scipy.interpolate

.. autofunction:: pchip