scipy.linalg.qr_multiply
========================

.. currentmodule:: scipy.linalg

.. autofunction:: qr_multiply