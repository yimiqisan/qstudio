scipy.io.netcdf.netcdf_file.close
=================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_file.close