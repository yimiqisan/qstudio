scipy.ndimage.measurements.minimum_position
===========================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: minimum_position