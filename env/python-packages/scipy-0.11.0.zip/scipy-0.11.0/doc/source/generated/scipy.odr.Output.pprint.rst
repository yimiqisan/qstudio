scipy.odr.Output.pprint
=======================

.. currentmodule:: scipy.odr

.. automethod:: Output.pprint