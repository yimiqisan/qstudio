scipy.fftpack.fft
=================

.. currentmodule:: scipy.fftpack

.. autofunction:: fft