scipy.ndimage.morphology.binary_propagation
===========================================

.. currentmodule:: scipy.ndimage.morphology

.. autofunction:: binary_propagation