scipy.optimize.fmin
===================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin