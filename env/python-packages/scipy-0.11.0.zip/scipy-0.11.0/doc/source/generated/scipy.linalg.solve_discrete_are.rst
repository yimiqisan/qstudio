scipy.linalg.solve_discrete_are
===============================

.. currentmodule:: scipy.linalg

.. autofunction:: solve_discrete_are