scipy.interpolate.BarycentricInterpolator.set_yi
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: BarycentricInterpolator.set_yi