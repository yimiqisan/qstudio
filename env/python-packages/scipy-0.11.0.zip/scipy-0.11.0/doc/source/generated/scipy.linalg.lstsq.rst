scipy.linalg.lstsq
==================

.. currentmodule:: scipy.linalg

.. autofunction:: lstsq