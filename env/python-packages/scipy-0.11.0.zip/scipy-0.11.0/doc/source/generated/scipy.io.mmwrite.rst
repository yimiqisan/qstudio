scipy.io.mmwrite
================

.. currentmodule:: scipy.io

.. autofunction:: mmwrite