scipy.ndimage.measurements.minimum
==================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: minimum