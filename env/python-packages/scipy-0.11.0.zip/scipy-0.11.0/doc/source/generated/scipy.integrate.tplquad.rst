scipy.integrate.tplquad
=======================

.. currentmodule:: scipy.integrate

.. autofunction:: tplquad