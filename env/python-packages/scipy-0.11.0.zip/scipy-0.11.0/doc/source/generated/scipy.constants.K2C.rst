scipy.constants.K2C
===================

.. currentmodule:: scipy.constants

.. autofunction:: K2C