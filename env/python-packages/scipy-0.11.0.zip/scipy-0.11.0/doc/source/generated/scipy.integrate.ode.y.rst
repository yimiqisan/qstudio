scipy.integrate.ode.y
=====================

.. currentmodule:: scipy.integrate

.. autoattribute:: ode.y