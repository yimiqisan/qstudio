scipy.ndimage.measurements.label
================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: label