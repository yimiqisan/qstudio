scipy.odr.odr_error
===================

.. currentmodule:: scipy.odr

.. autoexception:: odr_error