scipy.linalg.pascal
===================

.. currentmodule:: scipy.linalg

.. autofunction:: pascal