scipy.optimize.brentq
=====================

.. currentmodule:: scipy.optimize

.. autofunction:: brentq