scipy.odr.ODR.run
=================

.. currentmodule:: scipy.odr

.. automethod:: ODR.run