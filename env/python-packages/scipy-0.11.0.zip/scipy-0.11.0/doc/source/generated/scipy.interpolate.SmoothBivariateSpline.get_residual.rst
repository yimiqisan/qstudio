scipy.interpolate.SmoothBivariateSpline.get_residual
====================================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.get_residual