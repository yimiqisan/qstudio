scipy.interpolate.RectSphereBivariateSpline.get_residual
========================================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectSphereBivariateSpline.get_residual