scipy.optimize.fmin_powell
==========================

.. currentmodule:: scipy.optimize

.. autofunction:: fmin_powell