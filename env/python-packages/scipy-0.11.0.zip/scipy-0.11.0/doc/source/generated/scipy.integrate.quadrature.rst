scipy.integrate.quadrature
==========================

.. currentmodule:: scipy.integrate

.. autofunction:: quadrature