scipy.io.netcdf.netcdf_file.flush
=================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_file.flush