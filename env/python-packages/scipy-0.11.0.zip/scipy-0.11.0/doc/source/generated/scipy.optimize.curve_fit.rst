scipy.optimize.curve_fit
========================

.. currentmodule:: scipy.optimize

.. autofunction:: curve_fit