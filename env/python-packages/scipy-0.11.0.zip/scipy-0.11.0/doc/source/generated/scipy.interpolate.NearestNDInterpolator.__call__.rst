scipy.interpolate.NearestNDInterpolator.__call__
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: NearestNDInterpolator.__call__