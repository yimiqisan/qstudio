scipy.optimize.bisect
=====================

.. currentmodule:: scipy.optimize

.. autofunction:: bisect