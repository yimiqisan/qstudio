scipy.interpolate.RectSphereBivariateSpline.get_knots
=====================================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectSphereBivariateSpline.get_knots