scipy.interpolate.LSQBivariateSpline
====================================

.. currentmodule:: scipy.interpolate

.. autoclass:: LSQBivariateSpline

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         LSQBivariateSpline.__call__
         LSQBivariateSpline.ev
         LSQBivariateSpline.get_coeffs
         LSQBivariateSpline.get_knots
         LSQBivariateSpline.get_residual
         LSQBivariateSpline.integral



   

